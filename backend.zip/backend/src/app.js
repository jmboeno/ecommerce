const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");

// Rotas
const authRoute = require("./routes/authRoute");
const usersRoute = require("./routes/usersRoute");
const categoriesRoute = require("./routes/categoriesRoute");
const suppliersRoute = require("./routes/suppliersRoute");
const productsRoute = require("./routes/productsRoute");
const transactionsRoute = require("./routes/transactionsRoute");
const rolesRoute = require("./routes/rolesRoute");
const permissionsRoute = require("./routes/permissionsRoute");
const profileRoute = require("./routes/profileRoute");
const securityRoute = require("./routes/securityRoute");

const app = express();

// Middlewares globais
app.use(express.json());
app.use(cors({
	origin: "http://localhost:5173",
	credentials: true
}));
app.use(helmet());
app.use(morgan("dev"));

// Rotas
app.use("/auth", authRoute);
app.use("/security", securityRoute);
app.use("/dashboard/profile", profileRoute);
app.use("/dashboard/users", usersRoute);
app.use("/dashboard/roles", rolesRoute);
app.use("/dashboard/permissions", permissionsRoute);
app.use("/dashboard/products", productsRoute);
app.use("/dashboard/categories", categoriesRoute);
app.use("/dashboard/suppliers", suppliersRoute);
app.use("/dashboard/transactions", transactionsRoute);

// Middleware de erro global
app.use((err, req, res, next) => {
	console.error(err.stack);
	res.status(500).json({ message: "Erro interno do servidor" });
});

module.exports = app;