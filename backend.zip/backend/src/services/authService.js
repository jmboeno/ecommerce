const { User } = require("../models");
const { compare } = require("bcryptjs");
const { sign, verify, decode } = require("jsonwebtoken");
const jsonSecret = require("../config/jsonSecret");

const MIN_LOGIN_TIME_MS = 2000;

function generatePairToken(user) {
	if (!user || !user.id) {
		throw new Error("Usuário inválido para geração de token");
	}

	const accessToken = sign(
		{ id: user.id, email: user.email },
		jsonSecret.secret,
		{ expiresIn: "1h" }
	);

	const refreshToken = sign(
		{ id: user.id },
		jsonSecret.refreshSecret,
		{ expiresIn: "7d" }
	);

	return { accessToken, refreshToken };
}

function wait(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}

async function authenticate({ email, password }) {
	const startTime = Date.now();

	const user = await User.scope("withPassword").findOne({
		attributes: ["id", "email", "password_hash"],
		where: { email }
	});

	let response;

	if (!user) {
		response = { message: "Usuário ou senha incorreta!" };
	} else {
		const equalPassword = await compare(password, user.password_hash);

		if (!equalPassword) {
			response = { message: "Usuário ou senha incorreta!" };
		} else {
			response = generatePairToken(user);
		}
	}

	const elapsed = Date.now() - startTime;

	if (elapsed < MIN_LOGIN_TIME_MS) {
		await wait(MIN_LOGIN_TIME_MS - elapsed);
	}

	return response;
}

async function refreshToken(token) {
	if (!token) {
		return { error: "Refresh token não fornecido." };
	}

	try {
		// Validação do token de refresh
		verify(token, jsonSecret.refreshSecret);

		// Decodificar para pegar o id do usuário
		const { id } = decode(token);

		const user = await User.findByPk(id);

		if (!user) {
			return { error: "Usuário não encontrado." };
		}

		return generatePairToken(user);
	} catch (err) {
		return { error: "Refresh token inválido ou expirado." };
	}
}

module.exports = {
	authenticate,
	refreshToken
};
