const { Router } = require("express");
const { getRoles, postRole } = require("../controllers/rolesController");
const authenticated = require("../middleware/authenticated");

const router = Router();

router.use(authenticated);
router.get("/", getRoles);
// router.get("/:id", getProduct);
router.post("/", postRole);
// router.patch("/:id", patchProduct);
// router.delete("/:id", deleteProduct);

module.exports = router;