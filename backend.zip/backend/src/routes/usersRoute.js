const { Router } = require("express");
const { getUsers, getUser, postUser, patchUser, deleteUser } = require("../controllers/usersController");
const authenticated = require("../middleware/authenticated");
const { roles } = require("../middleware/roles");

const router = Router();

router.use(authenticated);

router.route("/")
	.get(roles(["Gerente"]), getUsers)
	.post(roles(["Gerente"]), postUser);

router.route("/:id")
	.get(roles(["Gerente"]), getUser)
	.patch(roles(["Gerente"]), patchUser)
	.delete(roles(["Gerente"]), deleteUser);

module.exports = router;
