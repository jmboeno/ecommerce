const { Router } = require("express");
const {
	postLogin,
	getRefresh,
	postUser,
	activateUser
} = require("../controllers/authController");

const router = Router();

// Login do usuário (gera token)
router.post("/login", postLogin);

// Refresh token
router.get("/refresh", getRefresh);

// Registro (Signup) — acesso público, mas restrito a dados mínimos
router.post("/register", postUser);

// Rota para ativação do usuário
router.get("/activate/:token", activateUser);

module.exports = router;
