const { authenticate, refreshToken } = require("../services/authService");
const { insertAcl } = require("../services/securityService");
const { insertUser } = require("../services/usersService");
const { sign, verify } = require("jsonwebtoken");
const jsonSecret = require("../config/jsonSecret");
const { User } = require("../models");

const DEFAULT_ROLE_ID = "77996b62-ee9e-4565-9b27-8042e3f1a9aa";
const DEFAULT_PERMISSION_ID = "c82dcce8-299c-409e-8b94-0c93a02079e8";

const ACTIVATION_TOKEN_EXPIRATION = "1d";
const ACTIVATION_URL_BASE = "http://localhost:3000/auth/activate"; 

async function postLogin(req, res) {
	const { email, password } = req.body;

	if (!email || !password) {
		return res.status(401).json({ message: "Email e senha são obrigatórios!" });
	}

	try {
		const { accessToken, refreshToken, message } = await authenticate({ email, password });

		if (accessToken && refreshToken)
			return res.status(200).json({ accessToken, refreshToken });

		return res.status(400).json({ message });
	} catch (error) {
		console.error("Erro no login:", error);
		return res.status(401).json({ message: "Erro no login!" });
	}
}

async function getRefresh(req, res) {
	const token = req.headers.authorization;

	if (!token) {
		return res.status(401).json({ message: "RefreshToken não informado!" });
	}

	const [_, currentRefreshToken] = token.split(" ");

	try {
		const {
			accessToken: newAccessToken,
			refreshToken: newRefreshToken,
			message
		} = await refreshToken(currentRefreshToken);

		if (newAccessToken && newRefreshToken)
			return res.status(200).json({
				accessToken: newAccessToken,
				refreshToken: newRefreshToken
			});

		return res.status(400).json({ message });
	} catch (error) {
		console.error("Erro ao atualizar token:", error);
		return res.status(401).json({ message: "Erro ao atualizar token!" });
	}
}

async function postUser(req, res) {
	const { name, email, password } = req.body;

	if (!name || !email || !password) {
		return res.status(422).json({ message: "Nome, email e senha são obrigatórios." });
	}

	try {
		// Criação do usuário
		const createdUser = await insertUser({ name, email, password, active: false });

		if (!createdUser || createdUser.message) {
			return res.status(409).json({ message: createdUser.message || "Erro ao criar usuário." });
		}

		// Gera token de ativação
		const activationToken = sign(
			{ id: createdUser.id, email: createdUser.email },
			jsonSecret.activationSecret,
			{ expiresIn: ACTIVATION_TOKEN_EXPIRATION }
		);

		const activationLink = `${ACTIVATION_URL_BASE}/${activationToken}`;

		// Atribuir ACL (role e permission padrão)
		await insertAcl({
			user_id: createdUser.id,
			roles: [DEFAULT_ROLE_ID],
			permissions: [DEFAULT_PERMISSION_ID]
		});

		return res.status(201).json({
			message: "Usuário registrado com sucesso!",
			user_id: createdUser.id,
			activationLink // Para testes, depois enviar por email
		});
	} catch (error) {
		console.error("Erro no registro:", error);
		return res.status(500).json({ message: "Erro interno ao registrar usuário." });
	}
}

async function activateUser(req, res) {
	const { token } = req.params;

	if (!token) {
		return res.status(400).json({ message: "Token de ativação não fornecido" });
	}

	try {
		// Verifica e decodifica o token
		const payload = verify(token, jsonSecret.activationSecret);

		const user = await User.findByPk(payload.id);

		if (!user) {
			return res.status(404).json({ message: "Usuário não encontrado" });
		}

		if (user.active) {
			return res.status(400).json({ message: "Usuário já ativado" });
		}

		user.active = true;
		await user.save();

		return res.status(200).json({ message: "Usuário ativado com sucesso!" });
	} catch (error) {
		return res.status(400).json({ message: "Token inválido ou expirado" });
	}
}

module.exports = {
	postLogin,
	getRefresh,
	postUser,
	activateUser
};